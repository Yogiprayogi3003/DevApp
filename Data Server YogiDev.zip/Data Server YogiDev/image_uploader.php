<?php

// Comprobamos que se ha enviado la imagen a través del método POST
if(isset($_FILES['image'])) {

  // Obtenemos la información de la imagen
  $file_name = $_FILES['image']['name'];
  $file_size = $_FILES['image']['size'];
  $file_tmp = $_FILES['image']['tmp_name'];
  $file_type = $_FILES['image']['type'];

  // Definimos la ruta donde se guardará la imagen en el servidor
  $file_path = "uploads/" . $file_name;

  // Movemos la imagen del directorio temporal al directorio definitivo
  move_uploaded_file($file_tmp, $file_path);

  // Comprobamos si se ha enviado el parámetro adicional
  if(isset($_POST['additionalParam'])) {
    // Enviamos el parámetro adicional como respuesta
    echo $_POST['additionalParam'];
  }

  // Enviamos un mensaje de éxito
  echo "La imagen se ha subido correctamente.";

} else {
  // Enviamos un mensaje de error si no se ha enviado la imagen
  echo "No se ha seleccionado ninguna imagen.";
}

?>